package com.carpe.panoptes.modules.frida

import android.content.Context
import com.carpe.panoptes.modules.spi.AnalyzerModule
import com.carpe.panoptes.nativebridge.ExecShim
import com.carpe.panoptes.python.PythonBridge
import java.io.File

/**
 * Módulo de instrumentación dinámica (F6, §9 del plan: "frida-server como
 * módulo, scripts de unpinning"). El único módulo que requiere root.
 *
 * Arquitectura honesta (ver aviso grande en python/frida_runner.py del
 * shell): esto SIEMPRE arranca frida-server correctamente en el
 * dispositivo — esa parte no depende de nada incierto, es solo copiar un
 * binario y ejecutarlo como root vía ExecShim. Lo que SÍ es incierto es
 * si Panoptes puede controlarlo desde el propio dispositivo (requiere el
 * paquete Python `frida`, con extensión nativa, vía Chaquopy). Si falla,
 * `analyze()` lo refleja en el resultado en vez de fingir éxito — y
 * frida-server se queda arrancado y disponible para controlarlo desde un
 * PC conectado al dispositivo, que es como se usa Frida normalmente.
 */
class FridaController : AnalyzerModule {

    private lateinit var moduleDir: File
    private var pythonBridge: PythonBridge? = null

    override fun id(): String = "frida-server"
    override fun version(): String = "16.1.4"

    override fun initialize(context: Context, workDir: File): Boolean {
        moduleDir = workDir.parentFile ?: return false
        val binario = File(moduleDir, "bin/frida-server")
        if (!binario.exists()) return false

        pythonBridge = try {
            PythonBridge(context)
        } catch (e: Exception) {
            null // el shell no tiene Chaquopy disponible por el motivo que sea; seguimos sin control on-device
        }
        return true
    }

    /**
     * apkPath aquí se usa solo para derivar el nombre de paquete a
     * instrumentar (se asume ya instalado — es el mismo que se analizó
     * estáticamente). outputDir recibe scripts.json con los eventos
     * capturados, si el control on-device funcionó.
     */
    override fun analyze(
        apkPath: String,
        outputDir: File,
        listener: AnalyzerModule.ProgressListener
    ): AnalyzerModule.ModuleResult {
        val binario = File(moduleDir, "bin/frida-server")
        if (!binario.exists()) {
            return AnalyzerModule.ModuleResult(false, "{}", emptyList(), error = "frida-server no disponible")
        }

        listener.onProgress("arrancando frida-server", 0)
        val codigoArranque = ExecShim.run(
            binary = binario,
            args = listOf("-l", "127.0.0.1:27042", "-D"), // -D: daemonize
            workDir = moduleDir
        )
        if (codigoArranque != 0) {
            return AnalyzerModule.ModuleResult(
                success = false, jsonOutput = "{}", outputFiles = emptyList(),
                error = "frida-server no arrancó (código $codigoArranque) — ¿tiene la app acceso root?"
            )
        }
        listener.onLog("frida-server escuchando en 127.0.0.1:27042")

        val bridge = pythonBridge
        if (bridge == null) {
            // frida-server sigue disponible aunque no podamos controlarlo
            // on-device: éxito parcial, el usuario puede conectarse desde un PC.
            return AnalyzerModule.ModuleResult(
                success = true,
                jsonOutput = "{\"serverStarted\":true,\"onDeviceControl\":false}",
                outputFiles = emptyList()
            )
        }

        listener.onProgress("instrumentando", 30)
        val targetPackage = inferirPaqueteDesdeApkPath(apkPath)
        val scriptPath = File(moduleDir, "scripts/ssl-unpinning-and-log.js")
        if (!scriptPath.exists()) {
            return AnalyzerModule.ModuleResult(
                success = true,
                jsonOutput = "{\"serverStarted\":true,\"onDeviceControl\":false,\"reason\":\"script no empaquetado en el módulo\"}",
                outputFiles = emptyList()
            )
        }

        val resultadoJson = try {
            bridge.runFrida(targetPackage, scriptPath.absolutePath, timeoutSeconds = 15)
        } catch (e: Exception) {
            "{\"error\":\"${e.message}\"}"
        }

        listener.onProgress("instrumentando", 100)

        val archivoSalida = File(outputDir, "frida-events.json")
        archivoSalida.writeText(resultadoJson)

        return AnalyzerModule.ModuleResult(
            success = true,
            jsonOutput = resultadoJson,
            outputFiles = listOf(archivoSalida.name)
        )
    }

    private fun inferirPaqueteDesdeApkPath(apkPath: String): String {
        // El nombre de archivo lo genera ApkExtractor como
        // "<packageName>-<version>-<original>.apk" (ver ingest/ApkExtractor.kt
        // del shell) — frágil pero evita tener que pasar el packageName por
        // todo el pipeline solo para este módulo. Mejora pendiente: que
        // AnalyzerModule.analyze() reciba el packageName explícitamente en
        // una versión futura del SPI (ver Apéndice B: solo por adición).
        return File(apkPath).name.substringBefore('-')
    }

    override fun shutdown() {
        // Nota: no matamos frida-server aquí a propósito — si el control
        // on-device falló, queremos que siga disponible para conectar desde
        // un PC sin tener que reinstalar/reabrir la app.
    }
}
